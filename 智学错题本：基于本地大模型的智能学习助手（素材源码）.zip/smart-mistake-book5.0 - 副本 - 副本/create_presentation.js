const pptxgen = require("pptxgenjs");

let pres = new pptxgen();
pres.layout = 'LAYOUT_16x9';
pres.author = 'AI智能错题本团队';
pres.title = 'AI智能错题本系统演示';

// Color palette - Tech/Science theme
const colors = {
  primary: "1E2761",      // Navy blue
  secondary: "065A82",    // Deep blue
  accent: "00A896",       // Teal
  light: "CADCFC",        // Ice blue
  white: "FFFFFF",
  dark: "21295C",         // Midnight
  text: "2D3748",         // Dark gray
  lightBg: "F7FAFC"       // Light background
};

// Helper function for shadows
const makeShadow = () => ({ type: "outer", blur: 4, offset: 2, angle: 135, color: "000000", opacity: 0.15 });

// ============== Slide 1: 封面 ==============
let slide1 = pres.addSlide();
slide1.background = { color: colors.primary };

// Decorative shapes
slide1.addShape(pres.shapes.RECTANGLE, {
  x: 0, y: 0, w: 10, h: 5.625,
  fill: { color: colors.dark, transparency: 30 }
});

slide1.addShape(pres.shapes.OVAL, {
  x: -1, y: -1, w: 4, h: 4,
  fill: { color: colors.accent, transparency: 80 }
});

slide1.addShape(pres.shapes.OVAL, {
  x: 7.5, y: 3.5, w: 4, h: 4,
  fill: { color: colors.secondary, transparency: 70 }
});

// Main title
slide1.addText("AI智能错题本系统", {
  x: 0.5, y: 1.8, w: 9, h: 1.2,
  fontSize: 54, fontFace: "Microsoft YaHei", bold: true,
  color: colors.white, align: "center"
});

// Subtitle
slide1.addText("科技赋能学习 · 错题成就进步", {
  x: 0.5, y: 3.1, w: 9, h: 0.6,
  fontSize: 24, fontFace: "Microsoft YaHei",
  color: colors.light, align: "center"
});

// Tag line
slide1.addText("竞赛获奖顶配版 · 本地大模型版", {
  x: 0.5, y: 4.2, w: 9, h: 0.5,
  fontSize: 18, fontFace: "Microsoft YaHei",
  color: colors.accent, align: "center"
});

// Bottom decoration
slide1.addShape(pres.shapes.RECTANGLE, {
  x: 3, y: 5.2, w: 4, h: 0.05,
  fill: { color: colors.accent }
});

// ============== Slide 2: 目录 ==============
let slide2 = pres.addSlide();
slide2.background = { color: colors.lightBg };

slide2.addText("目 录", {
  x: 0.5, y: 0.4, w: 9, h: 0.8,
  fontSize: 40, fontFace: "Microsoft YaHei", bold: true,
  color: colors.primary, align: "center"
});

const tocItems = [
  "01", "项目概述",
  "02", "核心亮点",
  "03", "技术架构",
  "04", "功能模块",
  "05", "界面展示",
  "06", "使用流程",
  "07", "竞赛亮点",
  "08", "总结展望"
];

tocItems.forEach((item, i) => {
  const col = i % 4;
  const row = Math.floor(i / 4);
  const x = 0.8 + col * 2.3;
  const y = 1.5 + row * 1.8;
  
  // Number circle
  slide2.addShape(pres.shapes.OVAL, {
    x: x, y: y, w: 0.8, h: 0.8,
    fill: { color: i < 4 ? colors.primary : colors.secondary }
  });
  
  slide2.addText(item, {
    x: x, y: y + 0.15, w: 0.8, h: 0.5,
    fontSize: 20, fontFace: "Arial", bold: true,
    color: colors.white, align: "center"
  });
  
  // Text
  slide2.addText(tocItems[i + 1], {
    x: x - 0.2, y: y + 0.9, w: 1.2, h: 0.4,
    fontSize: 12, fontFace: "Microsoft YaHei",
    color: colors.text, align: "center"
  });
});

// ============== Slide 3: 项目概述 ==============
let slide3 = pres.addSlide();
slide3.background = { color: colors.lightBg };

// Header bar
slide3.addShape(pres.shapes.RECTANGLE, {
  x: 0, y: 0, w: 10, h: 1,
  fill: { color: colors.primary }
});

slide3.addText("01  项目概述", {
  x: 0.5, y: 0.25, w: 9, h: 0.5,
  fontSize: 28, fontFace: "Microsoft YaHei", bold: true,
  color: colors.white, margin: 0
});

// Main content card
slide3.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 1.3, w: 9, h: 3.8,
  fill: { color: colors.white },
  shadow: makeShadow()
});

slide3.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 1.3, w: 0.08, h: 3.8,
  fill: { color: colors.accent }
});

slide3.addText("项目简介", {
  x: 0.8, y: 1.5, w: 8.5, h: 0.5,
  fontSize: 20, fontFace: "Microsoft YaHei", bold: true,
  color: colors.primary, margin: 0
});

slide3.addText([
  { text: "一款 Python 桌面端 AI 智能错题本", options: { breakLine: true } },
  { text: "", options: { breakLine: true } },
  { text: "主打", options: { bold: true } },
  { text: "炫酷科技感可视化界面", options: { bold: true, color: colors.accent } },
  { text: " + ", options: { breakLine: false } },
  { text: "硬核本地AI功能", options: { bold: true, color: colors.accent, breakLine: true } },
  { text: "", options: { breakLine: true } },
  { text: "适配", options: { bold: true } },
  { text: "中小学生/中学生", options: { breakLine: false } },
  { text: "使用，全程", options: { breakLine: false } },
  { text: "本地运行", options: { bold: true, color: colors.secondary } },
  { text: "、", options: { breakLine: false } },
  { text: "无付费接口", options: { bold: true, color: colors.secondary } },
  { text: "、", options: { breakLine: false } },
  { text: "无需联网", options: { bold: true, color: colors.secondary } },
  { text: "、", options: { breakLine: false } },
  { text: "不依赖云端API", options: { bold: true, color: colors.secondary } }
], {
  x: 0.8, y: 2.1, w: 8.5, h: 2.5,
  fontSize: 18, fontFace: "Microsoft YaHei",
  color: colors.text, valign: "top"
});

// Bottom stats
const stats = [
  { value: "100%", label: "本地运行" },
  { value: "0", label: "云端依赖" },
  { value: "0", label: "使用成本" }
];

stats.forEach((stat, i) => {
  const x = 1.2 + i * 2.8;
  slide3.addText(stat.value, {
    x: x, y: 4.6, w: 2, h: 0.6,
    fontSize: 32, fontFace: "Arial", bold: true,
    color: colors.accent, align: "center"
  });
  slide3.addText(stat.label, {
    x: x, y: 5.1, w: 2, h: 0.4,
    fontSize: 14, fontFace: "Microsoft YaHei",
    color: colors.text, align: "center"
  });
});

// ============== Slide 4: 核心亮点 ==============
let slide4 = pres.addSlide();
slide4.background = { color: colors.lightBg };

slide4.addShape(pres.shapes.RECTANGLE, {
  x: 0, y: 0, w: 10, h: 1,
  fill: { color: colors.primary }
});

slide4.addText("02  核心亮点", {
  x: 0.5, y: 0.25, w: 9, h: 0.5,
  fontSize: 28, fontFace: "Microsoft YaHei", bold: true,
  color: colors.white, margin: 0
});

const highlights = [
  { icon: "🤖", title: "本地大模型", desc: "接入本地部署DeepSeek-R1:7B大模型，实现AI错题深度剖析" },
  { icon: "🎨", title: "科技风界面", desc: "科技风卡片式布局，支持暗黑/明亮双主题切换" },
  { icon: "📷", title: "多模态录入", desc: "支持手动录入、复制粘贴、图片OCR识别多种方式" },
  { icon: "🧠", title: "艾宾浩斯", desc: "艾宾浩斯自适应复习引擎，科学记忆曲线" },
  { icon: "📊", title: "多维分类", desc: "按学科、知识点、错误原因等多维度筛选统计" },
  { icon: "💬", title: "AI答疑", desc: "针对错题实时解答，一对一智能辅导" }
];

highlights.forEach((item, i) => {
  const col = i % 3;
  const row = Math.floor(i / 3);
  const x = 0.5 + col * 3.1;
  const y = 1.3 + row * 2.0;
  
  // Card
  slide4.addShape(pres.shapes.RECTANGLE, {
    x: x, y: y, w: 2.9, h: 1.8,
    fill: { color: colors.white },
    shadow: makeShadow()
  });
  
  // Icon circle
  slide4.addShape(pres.shapes.OVAL, {
    x: x + 0.15, y: y + 0.15, w: 0.6, h: 0.6,
    fill: { color: colors.accent, transparency: 20 }
  });
  
  slide4.addText(item.icon, {
    x: x + 0.15, y: y + 0.2, w: 0.6, h: 0.5,
    fontSize: 24, align: "center"
  });
  
  // Title
  slide4.addText(item.title, {
    x: x + 0.85, y: y + 0.25, w: 1.9, h: 0.4,
    fontSize: 16, fontFace: "Microsoft YaHei", bold: true,
    color: colors.primary, margin: 0
  });
  
  // Description
  slide4.addText(item.desc, {
    x: x + 0.15, y: y + 0.85, w: 2.6, h: 0.8,
    fontSize: 11, fontFace: "Microsoft YaHei",
    color: colors.text, valign: "top"
  });
});

// ============== Slide 5: 技术架构 ==============
let slide5 = pres.addSlide();
slide5.background = { color: colors.lightBg };

slide5.addShape(pres.shapes.RECTANGLE, {
  x: 0, y: 0, w: 10, h: 1,
  fill: { color: colors.primary }
});

slide5.addText("03  技术架构", {
  x: 0.5, y: 0.25, w: 9, h: 0.5,
  fontSize: 28, fontFace: "Microsoft YaHei", bold: true,
  color: colors.white, margin: 0
});

// Tech stack items
const techStack = [
  { category: "开发语言", items: ["Python 3.10+"], color: colors.primary },
  { category: "界面框架", items: ["ttkbootstrap", "Tkinter"], color: colors.secondary },
  { category: "本地OCR", items: ["pytesseract", "PIL"], color: colors.accent },
  { category: "本地大模型", items: ["ollama", "deepseek-r1:7b"], color: "E07C24" },
  { category: "数据存储", items: ["本地JSON文件"], color: "8B5CF6" }
];

techStack.forEach((tech, i) => {
  const x = 0.5 + i * 1.9;
  const y = 1.4;
  
  // Category card
  slide5.addShape(pres.shapes.RECTANGLE, {
    x: x, y: y, w: 1.7, h: 2.4,
    fill: { color: colors.white },
    shadow: makeShadow()
  });
  
  // Top color bar
  slide5.addShape(pres.shapes.RECTANGLE, {
    x: x, y: y, w: 1.7, h: 0.08,
    fill: { color: tech.color }
  });
  
  // Category name
  slide5.addText(tech.category, {
    x: x, y: y + 0.2, w: 1.7, h: 0.4,
    fontSize: 12, fontFace: "Microsoft YaHei", bold: true,
    color: colors.text, align: "center"
  });
  
  // Items
  tech.items.forEach((item, j) => {
    slide5.addText(item, {
      x: x, y: y + 0.7 + j * 0.6, w: 1.7, h: 0.5,
      fontSize: 11, fontFace: "Consolas",
      color: tech.color, align: "center"
    });
  });
});

// Architecture diagram
slide5.addText("系统架构图", {
  x: 0.5, y: 4.0, w: 9, h: 0.4,
  fontSize: 16, fontFace: "Microsoft YaHei", bold: true,
  color: colors.primary
});

// Layer boxes
const layers = [
  { name: "用户界面层", y: 4.5, color: colors.primary },
  { name: "业务逻辑层", y: 4.85, color: colors.secondary },
  { name: "数据存储层", y: 5.2, color: colors.accent }
];

layers.forEach((layer, i) => {
  slide5.addShape(pres.shapes.RECTANGLE, {
    x: 0.5 + i * 3.2, y: layer.y, w: 2.8, h: 0.35,
    fill: { color: layer.color }
  });
  slide5.addText(layer.name, {
    x: 0.5 + i * 3.2, y: layer.y, w: 2.8, h: 0.35,
    fontSize: 12, fontFace: "Microsoft YaHei", bold: true,
    color: colors.white, align: "center", valign: "middle"
  });
});

// Arrows
slide5.addText("▼", {
  x: 1.9, y: 4.55, w: 0.3, h: 0.3,
  fontSize: 14, color: colors.text, align: "center"
});
slide5.addText("▼", {
  x: 5.1, y: 4.55, w: 0.3, h: 0.3,
  fontSize: 14, color: colors.text, align: "center"
});
slide5.addText("▼", {
  x: 8.3, y: 4.55, w: 0.3, h: 0.3,
  fontSize: 14, color: colors.text, align: "center"
});

// ============== Slide 6: 功能模块概览 ==============
let slide6 = pres.addSlide();
slide6.background = { color: colors.lightBg };

slide6.addShape(pres.shapes.RECTANGLE, {
  x: 0, y: 0, w: 10, h: 1,
  fill: { color: colors.primary }
});

slide6.addText("04  功能模块概览", {
  x: 0.5, y: 0.25, w: 9, h: 0.5,
  fontSize: 28, fontFace: "Microsoft YaHei", bold: true,
  color: colors.white, margin: 0
});

// Central circle
slide6.addShape(pres.shapes.OVAL, {
  x: 4, y: 2.4, w: 2, h: 2,
  fill: { color: colors.primary }
});

slide6.addText("AI智能\n错题本", {
  x: 4, y: 2.9, w: 2, h: 1,
  fontSize: 14, fontFace: "Microsoft YaHei", bold: true,
  color: colors.white, align: "center"
});

// Surrounding modules
const modules = [
  { name: "多模态\n智能录入", x: 1, y: 1.4, color: "F59E0B" },
  { name: "本地大模型\n分析", x: 7, y: 1.4, color: "10B981" },
  { name: "艾宾浩斯\n复习引擎", x: 1, y: 3.8, color: "3B82F6" },
  { name: "多维分类\n统计", x: 7, y: 3.8, color: "8B5CF6" },
  { name: "AI答疑\n互动", x: 4, y: 4.8, color: "EF4444" }
];

modules.forEach((mod, i) => {
  slide6.addShape(pres.shapes.OVAL, {
    x: mod.x, y: mod.y, w: 2, h: 1.2,
    fill: { color: mod.color },
    shadow: makeShadow()
  });
  
  slide6.addText(mod.name, {
    x: mod.x, y: mod.y + 0.3, w: 2, h: 0.8,
    fontSize: 12, fontFace: "Microsoft YaHei", bold: true,
    color: colors.white, align: "center"
  });
});

// Connecting lines (simplified with text arrows)
const arrows = [
  { x1: 3, y1: 2.0, x2: 3.8, y2: 2.6 },
  { x1: 6.2, y1: 2.6, x2: 7, y2: 2.0 },
  { x1: 3, y1: 4.4, x2: 3.8, y2: 3.8 },
  { x1: 6.2, y1: 3.8, x2: 7, y2: 4.4 },
  { x1: 5, y1: 4.4, x2: 5, y2: 4.4 }
];

// ============== Slide 7: 多模态智能录入 ==============
let slide7 = pres.addSlide();
slide7.background = { color: colors.lightBg };

slide7.addShape(pres.shapes.RECTANGLE, {
  x: 0, y: 0, w: 10, h: 1,
  fill: { color: colors.primary }
});

slide7.addText("04  多模态智能录入", {
  x: 0.5, y: 0.25, w: 9, h: 0.5,
  fontSize: 28, fontFace: "Microsoft YaHei", bold: true,
  color: colors.white, margin: 0
});

// Three input methods
const inputMethods = [
  { 
    icon: "⌨️", 
    title: "手动录入", 
    desc: "支持键盘输入题目内容",
    features: ["题目文本输入", "选择题自动识别", "多行文本支持"]
  },
  { 
    icon: "📋", 
    title: "复制粘贴", 
    desc: "从文档或网页粘贴内容",
    features: ["一键粘贴", "智能格式转换", "自动清理乱码"]
  },
  { 
    icon: "📷", 
    title: "OCR识别", 
    desc: "拍照或上传图片自动识别",
    features: ["pytesseract引擎", "中英文混合识别", "选项智能拆分"]
  }
];

inputMethods.forEach((method, i) => {
  const x = 0.5 + i * 3.1;
  
  // Card
  slide7.addShape(pres.shapes.RECTANGLE, {
    x: x, y: 1.3, w: 2.9, h: 3.8,
    fill: { color: colors.white },
    shadow: makeShadow()
  });
  
  // Icon
  slide7.addShape(pres.shapes.OVAL, {
    x: x + 0.95, y: 1.5, w: 1, h: 1,
    fill: { color: colors.accent, transparency: 20 }
  });
  
  slide7.addText(method.icon, {
    x: x + 0.95, y: 1.65, w: 1, h: 0.7,
    fontSize: 36, align: "center"
  });
  
  // Title
  slide7.addText(method.title, {
    x: x, y: 2.6, w: 2.9, h: 0.4,
    fontSize: 18, fontFace: "Microsoft YaHei", bold: true,
    color: colors.primary, align: "center"
  });
  
  // Description
  slide7.addText(method.desc, {
    x: x + 0.2, y: 3.0, w: 2.5, h: 0.4,
    fontSize: 11, fontFace: "Microsoft YaHei",
    color: colors.text, align: "center"
  });
  
  // Divider
  slide7.addShape(pres.shapes.LINE, {
    x: x + 0.5, y: 3.5, w: 1.9, h: 0,
    line: { color: colors.light, width: 1 }
  });
  
  // Features
  method.features.forEach((feature, j) => {
    slide7.addText("• " + feature, {
      x: x + 0.3, y: 3.7 + j * 0.4, w: 2.4, h: 0.35,
      fontSize: 11, fontFace: "Microsoft YaHei",
      color: colors.text
    });
  });
});

// ============== Slide 8: AI错题深度分析 ==============
let slide8 = pres.addSlide();
slide8.background = { color: colors.lightBg };

slide8.addShape(pres.shapes.RECTANGLE, {
  x: 0, y: 0, w: 10, h: 1,
  fill: { color: colors.primary }
});

slide8.addText("04  AI错题深度分析", {
  x: 0.5, y: 0.25, w: 9, h: 0.5,
  fontSize: 28, fontFace: "Microsoft YaHei", bold: true,
  color: colors.white, margin: 0
});

// Model info
slide8.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 1.3, w: 4.3, h: 1.5,
  fill: { color: colors.white },
  shadow: makeShadow()
});

slide8.addText("🤖", {
  x: 0.7, y: 1.5, w: 0.8, h: 0.8,
  fontSize: 36, align: "center"
});

slide8.addText("DeepSeek-R1:7B", {
  x: 1.5, y: 1.5, w: 3, h: 0.5,
  fontSize: 20, fontFace: "Arial", bold: true,
  color: colors.primary, margin: 0
});

slide8.addText("本地部署 · 离线运行 · 隐私安全", {
  x: 1.5, y: 2.0, w: 3, h: 0.4,
  fontSize: 12, fontFace: "Microsoft YaHei",
  color: colors.text, margin: 0
});

// Analysis items
const analysisItems = [
  { num: "01", title: "错误类型诊断", desc: "概念混淆/计算失误/审题不清/逻辑漏洞" },
  { num: "02", title: "错因深度剖析", desc: "详细解释学生为什么会犯这个错误" },
  { num: "03", title: "正确解法指导", desc: "给出完整的解题步骤和思路" },
  { num: "04", title: "考点精准讲解", desc: "解释本题考查的知识点和难点" },
  { num: "05", title: "避坑技巧分享", desc: "如何避免类似错误的技巧方法" },
  { num: "06", title: "同类变式练习", desc: "AI自动生成1-2道同类变式题" }
];

analysisItems.forEach((item, i) => {
  const col = i % 2;
  const row = Math.floor(i / 2);
  const x = 0.5 + col * 4.5;
  const y = 3.0 + row * 0.8;
  
  // Number
  slide8.addShape(pres.shapes.OVAL, {
    x: x, y: y, w: 0.5, h: 0.5,
    fill: { color: colors.accent }
  });
  
  slide8.addText(item.num, {
    x: x, y: y + 0.1, w: 0.5, h: 0.3,
    fontSize: 12, fontFace: "Arial", bold: true,
    color: colors.white, align: "center"
  });
  
  // Title
  slide8.addText(item.title, {
    x: x + 0.6, y: y, w: 1.8, h: 0.35,
    fontSize: 14, fontFace: "Microsoft YaHei", bold: true,
    color: colors.primary, margin: 0
  });
  
  // Description
  slide8.addText(item.desc, {
    x: x + 0.6, y: y + 0.35, w: 3.5, h: 0.35,
    fontSize: 10, fontFace: "Microsoft YaHei",
    color: colors.text, margin: 0
  });
});

// ============== Slide 9: 艾宾浩斯复习引擎 ==============
let slide9 = pres.addSlide();
slide9.background = { color: colors.lightBg };

slide9.addShape(pres.shapes.RECTANGLE, {
  x: 0, y: 0, w: 10, h: 1,
  fill: { color: colors.primary }
});

slide9.addText("04  艾宾浩斯复习引擎", {
  x: 0.5, y: 0.25, w: 9, h: 0.5,
  fontSize: 28, fontFace: "Microsoft YaHei", bold: true,
  color: colors.white, margin: 0
});

// Ebbinghaus curve explanation
slide9.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 1.3, w: 4.5, h: 2.0,
  fill: { color: colors.white },
  shadow: makeShadow()
});

slide9.addText("🧠 遗忘曲线原理", {
  x: 0.7, y: 1.5, w: 4, h: 0.4,
  fontSize: 16, fontFace: "Microsoft YaHei", bold: true,
  color: colors.primary, margin: 0
});

slide9.addText([
  { text: "根据艾宾浩斯遗忘曲线，复习间隔科学设置：", options: { breakLine: true } },
  { text: "", options: { breakLine: true } },
  { text: "1天 → 2天 → 4天 → 7天 → 15天 → 30天", options: { bold: true, color: colors.accent } }
], {
  x: 0.7, y: 2.0, w: 4, h: 1.2,
  fontSize: 12, fontFace: "Microsoft YaHei",
  color: colors.text
});

// Review intervals
const intervals = [
  { day: "1", label: "第1天" },
  { day: "2", label: "第2天" },
  { day: "4", label: "第4天" },
  { day: "7", label: "第7天" },
  { day: "15", label: "第15天" },
  { day: "30", label: "第30天" }
];

intervals.forEach((inv, i) => {
  const x = 5.2 + i * 0.75;
  const height = 0.5 + (i * 0.15);
  
  slide9.addShape(pres.shapes.RECTANGLE, {
    x: x, y: 1.3 + (1.5 - height), w: 0.6, h: height,
    fill: { color: i < 2 ? colors.accent : (i < 4 ? colors.secondary : colors.primary) }
  });
  
  slide9.addText(inv.day, {
    x: x, y: 1.35 + (1.5 - height), w: 0.6, h: 0.3,
    fontSize: 10, fontFace: "Arial", bold: true,
    color: colors.white, align: "center"
  });
  
  slide9.addText(inv.label, {
    x: x - 0.1, y: 2.95, w: 0.8, h: 0.3,
    fontSize: 8, fontFace: "Microsoft YaHei",
    color: colors.text, align: "center"
  });
});

slide9.addText("复习间隔递增", {
  x: 5.2, y: 3.3, w: 4.5, h: 0.3,
  fontSize: 10, fontFace: "Microsoft YaHei",
  color: colors.text, align: "center"
});

// Features
const reviewFeatures = [
  { icon: "📅", title: "智能提醒", desc: "自动计算下次复习时间" },
  { icon: "✅", title: "掌握标记", desc: "答对推进复习周期" },
  { icon: "🔄", title: "遗忘重置", desc: "答错重新开始周期" },
  { icon: "📈", title: "进度追踪", desc: "记录复习次数和状态" }
];

reviewFeatures.forEach((feat, i) => {
  const x = 0.5 + i * 2.4;
  
  slide9.addShape(pres.shapes.RECTANGLE, {
    x: x, y: 3.8, w: 2.2, h: 1.4,
    fill: { color: colors.white },
    shadow: makeShadow()
  });
  
  slide9.addText(feat.icon, {
    x: x, y: 3.95, w: 2.2, h: 0.5,
    fontSize: 24, align: "center"
  });
  
  slide9.addText(feat.title, {
    x: x, y: 4.45, w: 2.2, h: 0.35,
    fontSize: 14, fontFace: "Microsoft YaHei", bold: true,
    color: colors.primary, align: "center"
  });
  
  slide9.addText(feat.desc, {
    x: x, y: 4.8, w: 2.2, h: 0.3,
    fontSize: 10, fontFace: "Microsoft YaHei",
    color: colors.text, align: "center"
  });
});

// ============== Slide 10: 多维分类统计 ==============
let slide10 = pres.addSlide();
slide10.background = { color: colors.lightBg };

slide10.addShape(pres.shapes.RECTANGLE, {
  x: 0, y: 0, w: 10, h: 1,
  fill: { color: colors.primary }
});

slide10.addText("04  多维分类统计", {
  x: 0.5, y: 0.25, w: 9, h: 0.5,
  fontSize: 28, fontFace: "Microsoft YaHei", bold: true,
  color: colors.white, margin: 0
});

// Statistics cards
const statsData = [
  { icon: "📚", title: "按学科统计", items: ["数学", "语文", "英语", "物理", "化学", "生物", "历史", "地理", "政治"] },
  { icon: "🎯", title: "按知识点统计", items: ["支持自定义知识点标签", "多标签关联同一错题", "知识点关联分析"] },
  { icon: "❌", title: "按错误原因统计", items: ["概念混淆", "计算失误", "审题不清", "逻辑漏洞", "方法错误", "步骤遗漏"] }
];

statsData.forEach((stat, i) => {
  const x = 0.5 + i * 3.1;
  
  slide10.addShape(pres.shapes.RECTANGLE, {
    x: x, y: 1.3, w: 2.9, h: 3.0,
    fill: { color: colors.white },
    shadow: makeShadow()
  });
  
  slide10.addText(stat.icon, {
    x: x, y: 1.5, w: 2.9, h: 0.6,
    fontSize: 32, align: "center"
  });
  
  slide10.addText(stat.title, {
    x: x, y: 2.1, w: 2.9, h: 0.4,
    fontSize: 16, fontFace: "Microsoft YaHei", bold: true,
    color: colors.primary, align: "center"
  });
  
  slide10.addShape(pres.shapes.LINE, {
    x: x + 0.5, y: 2.6, w: 1.9, h: 0,
    line: { color: colors.light, width: 1 }
  });
  
  stat.items.forEach((item, j) => {
    slide10.addText("• " + item, {
      x: x + 0.2, y: 2.75 + j * 0.35, w: 2.5, h: 0.3,
      fontSize: 10, fontFace: "Microsoft YaHei",
      color: colors.text
    });
  });
});

// Bottom summary
slide10.addShape(pres.shapes.RECTANGLE, {
  x: 0.5, y: 4.5, w: 9, h: 0.9,
  fill: { color: colors.accent, transparency: 15 }
});

slide10.addText("📊 数据可视化分析 · 清晰了解学习薄弱环节 · 针对性加强训练", {
  x: 0.5, y: 4.7, w: 9, h: 0.5,
  fontSize: 14, fontFace: "Microsoft YaHei",
  color: colors.primary, align: "center"
});

// ============== Slide 11: AI答疑互动 ==============
let slide11 = pres.addSlide();
slide11.background = { color: colors.lightBg };

slide11.addShape(pres.shapes.RECTANGLE, {
  x: 0, y: 0, w: 10, h: 1,
  fill: { color: colors.primary }
});

slide11.addText("04  AI答疑互动", {
  x: 0.5, y: 0.25, w: 9, h: 0.5,
  fontSize: 28, fontFace: "Microsoft YaHei", bold: true,
  color: colors.white, margin: 0
});

// Chat interface mockup
slide11.addShape(pres.shapes.RECTANGLE, {
  x: 1.5, y: 1.3, w: 7, h: 3.8,
  fill: { color: colors.white },
  shadow: makeShadow()
});

// Chat header
slide11.addShape(pres.shapes.RECTANGLE, {
  x: 1.5, y: 1.3, w: 7, h: 0.6,
  fill: { color: colors.secondary }
});

slide11.addText("💬 AI学习助手", {
  x: 1.5, y: 1.4, w: 7, h: 0.4,
  fontSize: 14, fontFace: "Microsoft YaHei", bold: true,
  color: colors.white, align: "center"
});

// Chat messages
slide11.addShape(pres.shapes.RECTANGLE, {
  x: 2, y: 2.1, w: 5.5, h: 0.8,
  fill: { color: colors.light }
});

slide11.addText("👤 学生：这道题为什么选B不选C？", {
  x: 2.2, y: 2.3, w: 5.1, h: 0.4,
  fontSize: 12, fontFace: "Microsoft YaHei",
  color: colors.text
});

slide11.addShape(pres.shapes.RECTANGLE, {
  x: 2, y: 3.1, w: 5.5, h: 1.2,
  fill: { color: colors.accent, transparency: 20 }
});

slide11.addText("🤖 AI：根据题意，这是一个关于...的题目。选项B正确是因为...", {
  x: 2.2, y: 3.2, w: 5.1, h: 1.0,
  fontSize: 12, fontFace: "Microsoft YaHei",
  color: colors.text
});

// Features
const qaFeatures = [
  { icon: "❓", text: "实时问答" },
  { icon: "📖", text: "知识讲解" },
  { icon: "💡", text: "思路点拨" },
  { icon: "🎓", text: "一对一辅导" }
];

qaFeatures.forEach((feat, i) => {
  const x = 1.8 + i * 1.7;
  
  slide11.addShape(pres.shapes.OVAL, {
    x: x, y: 4.5, w: 1.4, h: 0.8,
    fill: { color: colors.accent, transparency: 30 }
  });
  
  slide11.addText(feat.icon + "\n" + feat.text, {
    x: x, y: 4.6, w: 1.4, h: 0.6,
    fontSize: 9, fontFace: "Microsoft YaHei",
    color: colors.text, align: "center"
  });
});

// ============== Slide 12: 界面展示 ==============
let slide12 = pres.addSlide();
slide12.background = { color: colors.lightBg };

slide12.addShape(pres.shapes.RECTANGLE, {
  x: 0, y: 0, w: 10, h: 1,
  fill: { color: colors.primary }
});

slide12.addText("05  界面展示", {
  x: 0.5, y: 0.25, w: 9, h: 0.5,
  fontSize: 28, fontFace: "Microsoft YaHei", bold: true,
  color: colors.white, margin: 0
});

// UI Features
const uiFeatures = [
  { icon: "🎨", title: "科技风界面", desc: "卡片式布局，视觉效果出众" },
  { icon: "🌙", title: "双主题切换", desc: "暗黑/明亮模式自由切换" },
  { icon: "✨", title: "动画效果", desc: "标题动画、悬停效果增强体验" },
  { icon: "📱", title: "响应式设计", desc: "自适应窗口大小" }
];

uiFeatures.forEach((feat, i) => {
  const col = i % 2;
  const row = Math.floor(i / 2);
  const x = 0.5 + col * 4.6;
  const y = 1.3 + row * 1.8;
  
  slide12.addShape(pres.shapes.RECTANGLE, {
    x: x, y: y, w: 4.4, h: 1.5,
    fill: { color: colors.white },
    shadow: makeShadow()
  });
  
  slide12.addShape(pres.shapes.RECTANGLE, {
    x: x, y: y, w: 0.08, h: 1.5,
    fill: { color: colors.accent }
  });
  
  slide12.addText(feat.icon, {
    x: x + 0.3, y: y + 0.3, w: 0.8, h: 0.8,
    fontSize: 32, align: "center"
  });
  
  slide12.addText(feat.title, {
    x: x + 1.2, y: y + 0.3, w: 2.8, h: 0.4,
    fontSize: 16, fontFace: "Microsoft YaHei", bold: true,
    color: colors.primary, margin: 0
  });
  
  slide12.addText(feat.desc, {
    x: x + 1.2, y: y + 0.75, w: 2.8, h: 0.5,
    fontSize: 12, fontFace: "Microsoft YaHei",
    color: colors.text, margin: 0
  });
});

// Theme preview
slide12.addText("主题预览", {
  x: 0.5, y: 4.2, w: 9, h: 0.4,
  fontSize: 14, fontFace: "Microsoft YaHei", bold: true,
  color: colors.primary
});

const themes = [
  { name: "暗夜黑", color: "1A1A2E", preview: "darkly" },
  { name: "明亮白", color: "FFFFFF", preview: "flatly" },
  { name: "星空蓝", color: "1C2833", preview: "superhero" }
];

themes.forEach((theme, i) => {
  const x = 0.5 + i * 3.1;
  
  slide12.addShape(pres.shapes.RECTANGLE, {
    x: x, y: 4.6, w: 2.9, h: 0.8,
    fill: { color: theme.color },
    line: { color: colors.light, width: 1 }
  });
  
  slide12.addText(theme.name, {
    x: x, y: 4.8, w: 2.9, h: 0.4,
    fontSize: 12, fontFace: "Microsoft YaHei",
    color: theme.color === "FFFFFF" ? colors.text : colors.white, align: "center"
  });
});

// ============== Slide 13: 使用流程 ==============
let slide13 = pres.addSlide();
slide13.background = { color: colors.lightBg };

slide13.addShape(pres.shapes.RECTANGLE, {
  x: 0, y: 0, w: 10, h: 1,
  fill: { color: colors.primary }
});

slide13.addText("06  使用流程", {
  x: 0.5, y: 0.25, w: 9, h: 0.5,
  fontSize: 28, fontFace: "Microsoft YaHei", bold: true,
  color: colors.white, margin: 0
});

// Flow steps
const flowSteps = [
  { num: "1", title: "安装配置", desc: "安装Python依赖\n配置ollama\n拉取DeepSeek模型" },
  { num: "2", title: "录入错题", desc: "手动/粘贴/OCR\n选择学科\n标注知识点" },
  { num: "3", title: "AI分析", desc: "自动深度剖析\n生成变式题\n查找相似错题" },
  { num: "4", title: "复习巩固", desc: "艾宾浩斯计划\n卡片式复习\n掌握程度追踪" },
  { num: "5", title: "数据管理", desc: "多维统计分析\n数据备份\n持续优化" }
];

flowSteps.forEach((step, i) => {
  const x = 0.4 + i * 1.9;
  
  // Circle
  slide13.addShape(pres.shapes.OVAL, {
    x: x + 0.5, y: 1.4, w: 0.8, h: 0.8,
    fill: { color: colors.accent }
  });
  
  slide13.addText(step.num, {
    x: x + 0.5, y: 1.55, w: 0.8, h: 0.5,
    fontSize: 24, fontFace: "Arial", bold: true,
    color: colors.white, align: "center"
  });
  
  // Arrow
  if (i < 4) {
    slide13.addText("→", {
      x: x + 1.4, y: 1.55, w: 0.5, h: 0.5,
      fontSize: 24, color: colors.accent, align: "center"
    });
  }
  
  // Card
  slide13.addShape(pres.shapes.RECTANGLE, {
    x: x, y: 2.4, w: 1.8, h: 2.8,
    fill: { color: colors.white },
    shadow: makeShadow()
  });
  
  slide13.addText(step.title, {
    x: x, y: 2.55, w: 1.8, h: 0.4,
    fontSize: 14, fontFace: "Microsoft YaHei", bold: true,
    color: colors.primary, align: "center"
  });
  
  slide13.addShape(pres.shapes.LINE, {
    x: x + 0.3, y: 3.0, w: 1.2, h: 0,
    line: { color: colors.light, width: 1 }
  });
  
  slide13.addText(step.desc, {
    x: x + 0.1, y: 3.15, w: 1.6, h: 1.8,
    fontSize: 10, fontFace: "Microsoft YaHei",
    color: colors.text, align: "center"
  });
});

// ============== Slide 14: 竞赛亮点 ==============
let slide14 = pres.addSlide();
slide14.background = { color: colors.lightBg };

slide14.addShape(pres.shapes.RECTANGLE, {
  x: 0, y: 0, w: 10, h: 1,
  fill: { color: colors.primary }
});

slide14.addText("07  竞赛亮点", {
  x: 0.5, y: 0.25, w: 9, h: 0.5,
  fontSize: 28, fontFace: "Microsoft YaHei", bold: true,
  color: colors.white, margin: 0
});

const competitionHighlights = [
  { icon: "👑", title: "颜值碾压", desc: "科技风双主题界面，卡片式布局，动画效果增强用户体验" },
  { icon: "⚙️", title: "技术硬核", desc: "融合OCR、本地大模型、NLP、遗忘曲线算法等多重技术" },
  { icon: "🤖", title: "AI能力升级", desc: "真正的AI辅导能力，DeepSeek-R1:7B深度诊断错题" },
  { icon: "🎯", title: "实用性拉满", desc: "解决学生核心痛点，错题管理+AI分析+科学复习" },
  { icon: "📦", title: "完整交付", desc: "本地运行、零部署成本、开箱即用" }
];

competitionHighlights.forEach((item, i) => {
  const y = 1.3 + i * 0.82;
  
  slide14.addShape(pres.shapes.RECTANGLE, {
    x: 0.5, y: y, w: 9, h: 0.7,
    fill: { color: colors.white },
    shadow: makeShadow()
  });
  
  slide14.addShape(pres.shapes.OVAL, {
    x: 0.7, y: y + 0.1, w: 0.5, h: 0.5,
    fill: { color: colors.accent }
  });
  
  slide14.addText(item.icon, {
    x: 0.7, y: y + 0.15, w: 0.5, h: 0.4,
    fontSize: 20, align: "center"
  });
  
  slide14.addText(item.title, {
    x: 1.4, y: y + 0.15, w: 1.5, h: 0.4,
    fontSize: 16, fontFace: "Microsoft YaHei", bold: true,
    color: colors.primary, margin: 0
  });
  
  slide14.addText(item.desc, {
    x: 3.0, y: y + 0.15, w: 6, h: 0.4,
    fontSize: 12, fontFace: "Microsoft YaHei",
    color: colors.text, margin: 0
  });
});

// ============== Slide 15: 总结展望 ==============
let slide15 = pres.addSlide();
slide15.background = { color: colors.primary };

// Decorative shapes
slide15.addShape(pres.shapes.OVAL, {
  x: -2, y: -2, w: 5, h: 5,
  fill: { color: colors.secondary, transparency: 70 }
});

slide15.addShape(pres.shapes.OVAL, {
  x: 7, y: 3, w: 5, h: 5,
  fill: { color: colors.accent, transparency: 80 }
});

slide15.addText("08  总结展望", {
  x: 0.5, y: 0.8, w: 9, h: 0.6,
  fontSize: 36, fontFace: "Microsoft YaHei", bold: true,
  color: colors.white, align: "center"
});

// Summary points
const summaryPoints = [
  "科技赋能学习，让错题成为进步的阶梯",
  "本地AI大模型，保护隐私安全",
  "艾宾浩斯算法，科学记忆巩固",
  "多维度分析，精准定位薄弱环节"
];

summaryPoints.forEach((point, i) => {
  slide15.addShape(pres.shapes.RECTANGLE, {
    x: 1.5, y: 1.8 + i * 0.7, w: 7, h: 0.55,
    fill: { color: colors.white, transparency: 85 }
  });
  
  slide15.addText("✓  " + point, {
    x: 1.7, y: 1.88 + i * 0.7, w: 6.6, h: 0.4,
    fontSize: 16, fontFace: "Microsoft YaHei",
    color: colors.white
  });
});

// Closing
slide15.addText("让每个学生都能成为学霸！", {
  x: 0.5, y: 4.6, w: 9, h: 0.6,
  fontSize: 24, fontFace: "Microsoft YaHei", bold: true,
  color: colors.accent, align: "center"
});

// Bottom decoration
slide15.addShape(pres.shapes.RECTANGLE, {
  x: 3.5, y: 5.3, w: 3, h: 0.05,
  fill: { color: colors.white }
});

// ============== Slide 16: 致谢 ==============
let slide16 = pres.addSlide();
slide16.background = { color: colors.dark };

// Central content
slide16.addText("感谢观看", {
  x: 0.5, y: 2.0, w: 9, h: 1,
  fontSize: 56, fontFace: "Microsoft YaHei", bold: true,
  color: colors.white, align: "center"
});

slide16.addText("AI智能错题本系统", {
  x: 0.5, y: 3.2, w: 9, h: 0.6,
  fontSize: 24, fontFace: "Microsoft YaHei",
  color: colors.light, align: "center"
});

slide16.addShape(pres.shapes.RECTANGLE, {
  x: 4, y: 4.0, w: 2, h: 0.05,
  fill: { color: colors.accent }
});

slide16.addText("欢迎体验交流", {
  x: 0.5, y: 4.3, w: 9, h: 0.5,
  fontSize: 18, fontFace: "Microsoft YaHei",
  color: colors.accent, align: "center"
});

// Save the presentation
pres.writeFile({ fileName: "AI智能错题本系统演示.pptx" })
  .then(() => console.log("PPT created successfully: AI智能错题本系统演示.pptx"))
  .catch(err => console.error("Error creating PPT:", err));
